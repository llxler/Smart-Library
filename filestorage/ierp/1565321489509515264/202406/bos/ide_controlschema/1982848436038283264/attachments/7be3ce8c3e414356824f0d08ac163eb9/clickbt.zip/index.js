/**
 *  自定义控件书写模板
 */
(function(KDApi, $){
    // 构造函数，变量名随意，与最后一句代码的KDApi.register的第二个参数一致即可
    function testbt (model) {
        this._setModel(model)
    }

    // 原型中封装生命周期函数，固定格式
    testbt.prototype = {
        _setModel: function(model) {
            this.model = model
        },
        init: function(props){
            // TO DO
            initFunc(this.model, props)
		console.log('fuck1',this.model,props);
        },
        update: function(props){
            // TO DO
console.log('fuck2',this.model,props);
        },
        destoryed: function(){
            // TO DO
console.log('fuck3',this.model,props);
        }
    }

    var initFunc = function(model, props) {
        // KDApi.loadFile可以通过路径加载js或css文件，并且在html文件头生成script或者link标签，第一个参数是路径，第二个参数是model，第三个参数是加载完成后执行的回调函数

        KDApi.loadFile(['./js/fuck.js','./css/testbt.css'], model, function() {
            // 通过路径去获取html字符串，第一个参数是路径，第二个参数是model，第三个参数是HTML模板中变量的值
            KDApi.getTemplateStringByFilePath('./html/testbt.html', model, {
                //text: ''
            }).then(function(result) {
                model.dom.innerHTML = result
                initEvent(model, props)
            })
        })
    }

    var initEvent = function(model, props){
        //内置了jquery对象，可直接使用$
        $('.testbt', model.dom).click(function(){
            // model.invoke，用于给后端发送请求，第一个参数是事件名，可自定义；第二个参数是发送给后端的数据，可以是任意类型
            // model.invoke('click', 'Hello World!')
            alert("hello world");
        })
    }

    // KDApi注册一个id号，这个id号要和控件方案的id号对应
    KDApi.register('clickbt', testbt)
})(window.KDApi, jQuery) // 这里的jQuery不是必须要传进去的，可移除，要用到的时候才传，PC端系统默认会有jQuery对象，版本是1.12.4