console.log('fuck000');

window.addEventListener("click", ()=> {
        const counters=document.querySelectorAll(".counters span");
        const container=document.querySelector(".counters");
        //Variable that tracks if the counters have been activated
        let activated=false;

        function activateCounters() {
            if (activated===false) {
                counters.forEach(counter=> {
                        counter.innerText=0;

                        let count=0;

                        function updateCount() {
                            //Get counter target number to count to
                            const target=parseInt(counter.dataset.count);

                            if (count < target) {
                                count++;
                                counter.innerText=count;
                                setTimeout(updateCount, 10);
                            }

                            else {
                                counter.innerText=target;
                            }
                        }

                        //Run the function initially
                        updateCount();
                        //Set activated to true
                        activated=true;
                    });
            }
        }

        // Check if the counters should be activated on page load

        activateCounters();


        // Activate counters when scrolling to the specified position
        window.addEventListener("scroll", ()=> {
                if (window.pageYOffset > container.offsetTop - container.offsetHeight - 200) {
                    activateCounters();
                }
            });
    });
    console.log('fuck111');